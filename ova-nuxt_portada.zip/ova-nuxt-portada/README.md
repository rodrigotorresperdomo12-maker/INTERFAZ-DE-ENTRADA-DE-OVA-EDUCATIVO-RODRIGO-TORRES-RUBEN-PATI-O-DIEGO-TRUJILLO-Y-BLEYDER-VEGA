# OVA: Ciudadanos digitales, decido con cabeza y corazón (solo portada)

Versión recortada del OVA: contiene únicamente la interfaz inicial de entrada
(portada con Búho y Pixel, tema, palabras clave y botones «Sí, quiero entrar» / «No, por ahora»).
Proyecto Nuxt 3 + Vue 3 (modo SPA, sitio estático).

## Uso
```bash
npm install
npm run dev        # desarrollo en http://localhost:3000
npm run generate   # sitio estático en .output/public
```

## Estructura
- `app.vue`: plantilla y lógica de la portada.
- `assets/css/main.css` y `assets/css/mejoras.css`: solo los estilos que usa la portada.
- `nuxt.config.ts`: SPA, fuentes y metadatos.

## Nota
El botón «Sí, quiero entrar» celebra con confeti y sonido, pero no abre otra pantalla porque el resto del OVA se quitó.
La función `enter` de `app.vue` es el punto donde se conectaría la siguiente pantalla.
