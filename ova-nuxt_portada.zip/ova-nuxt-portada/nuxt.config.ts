export default defineNuxtConfig({
  compatibilityDate: '2025-01-01',
  ssr: false, // OVA 100 % en el navegador: se publica como sitio estático
  devtools: { enabled: false },
  css: ['~/assets/css/main.css', '~/assets/css/mejoras.css'],
  app: {
    head: {
      htmlAttrs: { lang: 'es' },
      title: 'Ciudadanos digitales: decido con cabeza y corazón',
      meta: [
        { name: 'viewport', content: 'width=device-width, initial-scale=1, viewport-fit=cover' },
        { name: 'description', content: 'OVA de ciudadanía digital para grado 6: huella digital, cyberbullying y netiqueta.' },
        { name: 'theme-color', content: '#1d2b5c' }
      ],
      link: [
        { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
        { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: '' },
        { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;800&family=Nunito:wght@400;700&display=swap' }
      ]
    }
  }
})
