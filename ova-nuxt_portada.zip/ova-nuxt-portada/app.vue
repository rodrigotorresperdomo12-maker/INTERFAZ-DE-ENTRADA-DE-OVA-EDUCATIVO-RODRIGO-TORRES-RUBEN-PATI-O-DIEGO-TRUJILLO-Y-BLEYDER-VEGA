<template>
<div id="app">
<i class="cf" v-for="c in conf" :key="c.id" :style="c.s"></i>
<transition name="gate">
<div class="gate" v-if="gate!=='in'" role="dialog" aria-modal="true" aria-label="Ciudadanos digitales: portada">
 <div class="g-bg" aria-hidden="true"><i class="gf" v-for="(e,i) in GF" :key="i" :style="{left:e[1]+'%',animationDelay:e[2]+'s',animationDuration:e[3]+'s',fontSize:e[4]+'rem'}">{{e[0]}}</i></div>
 <transition name="gpanel" mode="out-in">
 <div class="g-card" v-if="gate==='intro'" key="intro">
  <div class="g-logo" aria-hidden="true">🛡️</div>
  <p class="g-kicker">Objeto Virtual de Aprendizaje · Grado 6</p>
  <h1 class="g-title"><span class="gw" v-for="(w,a) in TW" :key="a"><span class="ch" aria-hidden="true" v-for="(c,b) in w" :key="b" :style="{'--i':a*10+b}">{{c}}</span><span class="sr">{{w}}</span></span></h1>
  <p class="g-sub">Decido con cabeza y corazón</p>
  <div class="g-topic"><b>🎯 Tema</b><p>Uso responsable de redes y ciudadanía digital: huella digital, prevención del cyberbullying y netiqueta.</p><ul class="kw"><li v-for="(k,i) in KW" :key="k" :style="{animationDelay:(1.6+i*.09)+'s'}">{{k}}</li></ul></div>
  <div class="g-crew"><div class="g-pet" v-for="(c,w) in CH" :key="w" :class="'p'+w"><button class="pb" :class="mood[w]" :aria-label="'Saludar a '+c[1]" @click="gPoke(w)">{{c[0]}}</button><b>{{c[1]}}</b><small>{{CR[w]}}</small></div></div>
  <transition name="slide" mode="out-in"><p class="g-say" :key="gi" aria-live="polite"><span><b>{{CH[GL[gi][0]][0]}} {{CH[GL[gi][0]][1]}}:</b> {{GL[gi][1]}}</span></p></transition>
  <div class="g-stats"><span>🎮 5 casos</span><span>⚡ 19 retos</span><span>🏅 14 insignias</span><span>⏱️ 2 sesiones de 45 min</span></div>
  <p class="g-q">¿Quieres entrar a la misión?</p>
  <div class="g-btns"><button class="main-btn g-yes" v-ripple v-magnet v-focus @click="enter">🚀 ¡Sí, quiero entrar!</button><button class="g-nob" @click="later">No, por ahora</button></div>
  <p class="g-note">No pide cuentas ni datos personales. Tú decides si entras.</p>
 </div>
 <div class="g-card g-bye" v-else key="no">
  <div class="g-em" aria-hidden="true">👋</div>
  <h2>¡Está bien!</h2>
  <p>Sin problema. La misión seguirá aquí cuando quieras entrar.</p>
  <div class="g-btns"><button class="main-btn g-yes" v-ripple v-magnet v-focus @click="enter">🚀 Mejor sí, ¡entrar!</button><button class="g-nob" @click="toIntro">Volver a la portada</button></div>
 </div>
 </transition>
</div>
</transition>
</div>
</template>

<script>
import {ref,reactive,getCurrentInstance} from 'vue'
const KW=["ciudadanía digital","huella digital","cyberbullying","netiqueta","redes sociales","toma de decisiones","grado 6"];
const CH=[["🦉","Búho"],["🦊","Pixel"]];
const TW=["Ciudadanos","digitales"],CR=["Guía de la misión","Compañero curioso"];
const GL=[[0,"¡Hola! Soy Búho, tu guía en esta misión.","wave"],[1,"Y yo soy Pixel. ¡Yo cuido que nadie se aburra!","hop"],[0,"Hablaremos de huella digital, cyberbullying y netiqueta."],[1,"¡Y habrá casos, retos e insignias!","hop"],[0,"¿Te animas a entrar?","wave"]];
const GF=[["💬",8,0,13,1.8],["❤️",22,3,16,1.4],["📷",38,6,12,2],["🔐",54,1.5,15,1.6],["👣",68,4.5,14,1.5],["🛡️",82,8,17,2],["⭐",92,2.5,12,1.2],["🚩",14,9,15,1.5]];
export default {setup(){
 registerGlobals(getCurrentInstance().appContext.app);
 const gate=ref("intro"),conf=ref([]),mood=reactive(["",""]),gi=ref(0),snd=ref(true);
 let cid=0,ac,gt;
 const burst=()=>{const ids=[];for(let i=0;i<40;i++){const id=++cid;ids.push(id);conf.value.push({id,s:{left:Math.random()*100+"vw",background:["#ffc93c","#e8545a","#0e8f8f","#6b7cff"][i%4],"--x":(Math.random()*160-80)+"px",animationDelay:Math.random()*.5+"s"}})}
  setTimeout(()=>{conf.value=conf.value.filter(c=>!ids.includes(c.id))},3000)};
 const beep=(fs,t=.12)=>{if(!snd.value)return;try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();fs.forEach((f,i)=>{const o=ac.createOscillator(),g=ac.createGain(),s=ac.currentTime+i*t;o.frequency.value=f;o.type="triangle";g.gain.setValueAtTime(.12,s);g.gain.exponentialRampToValueAtTime(.001,s+t);o.connect(g);g.connect(ac.destination);o.start(s);o.stop(s+t)})}catch(e){}};
 const tone=(f,d=.1,ty="sine",v=.1,dl=0,sl=0)=>{if(!snd.value)return;try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();if(ac.state==="suspended")ac.resume();const o=ac.createOscillator(),g=ac.createGain(),t0=ac.currentTime+dl;o.type=ty;o.frequency.setValueAtTime(f,t0);if(sl)o.frequency.exponentialRampToValueAtTime(sl,t0+d);g.gain.setValueAtTime(v,t0);g.gain.exponentialRampToValueAtTime(.001,t0+d);o.connect(g);g.connect(ac.destination);o.start(t0);o.stop(t0+d)}catch(e){}};
 const SFX={click:()=>tone(520,.07,"square",.05,0,800),hover:()=>tone(1000,.03,"sine",.02),tab:()=>{tone(420,.08,"triangle",.09,0,640);tone(640,.1,"triangle",.07,.07)},pop:()=>tone(280,.12,"sine",.1,0,720),open:()=>{tone(330,.09,"triangle",.08);tone(495,.1,"triangle",.07,.06)},close:()=>tone(520,.12,"triangle",.08,0,260),chirp:()=>{tone(900,.06,"sine",.06,0,1300);tone(1300,.08,"sine",.05,.07,1700)}};
 const sfxOf=el=>el.closest(".cx")?"close":el.closest("nav button,[role=tab]")?"tab":el.closest(".opt,.tile,.gbtn,.cell")?"pop":el.closest("summary")?"open":el.closest("button,a[href]")?"click":null;
 let lh=null,lt=0;const rm=()=>matchMedia("(prefers-reduced-motion:reduce)").matches;
 const mk=(c,x,y)=>{const i=document.createElement("i");i.className=c;i.style.left=x+"px";i.style.top=y+"px";document.body.appendChild(i);setTimeout(()=>i.remove(),750)};
 document.addEventListener("pointerdown",e=>{const el=e.target instanceof Element?e.target:null;if(!el)return;const k=sfxOf(el);if(k&&!el.closest("button:disabled"))SFX[k]();if(el.closest("button,summary")&&!rm())mk("cr",e.clientX,e.clientY)});
 document.addEventListener("pointerover",e=>{if(e.pointerType!=="mouse"||!(e.target instanceof Element))return;const b=e.target.closest("button:not(:disabled),summary,a[href]");if(b&&b!==lh&&!b.contains(e.relatedTarget)){lh=b;b.classList.contains("cib")?SFX.chirp():SFX.hover()}});
 document.addEventListener("pointermove",e=>{const n=Date.now();if(e.pointerType!=="mouse"||n-lt<70||rm())return;lt=n;mk("tr",e.clientX,e.clientY)});
 const act=(w,m)=>{mood[w]=m;setTimeout(()=>{mood[w]=""},700)};
 const gPlay=()=>{clearInterval(gt);gi.value=0;act(0,"wave");gt=setInterval(()=>{gi.value=(gi.value+1)%GL.length;act(GL[gi.value][0],GL[gi.value][2]||"hop")},3400)};
 gPlay();
 const gPoke=w=>{act(w,w?"spin":"wave");beep([w?740:520])};
 // Al pulsar "entrar" se celebra y la portada se queda; aquí se conectaría la siguiente pantalla.
 const enter=()=>{burst();beep([523,659,784,1047]);act(0,"dance");act(1,"dance")};
 const later=()=>{gate.value="no";act(0,"wave");act(1,"shk");beep([392,330])};
 const toIntro=()=>{gate.value="intro";scrollTo(0,0);gPlay()};
 return{gate,conf,mood,gi,KW,CH,TW,CR,GL,GF,gPoke,enter,later,toIntro}
}};
function registerGlobals(app){
app.directive("ripple",{mounted(el){el.addEventListener("pointerdown",e=>{if(el.disabled)return;const r=el.getBoundingClientRect(),d=Math.max(r.width,r.height),s=document.createElement("i");s.className="rp";s.style.cssText="width:"+d+"px;height:"+d+"px;left:"+(e.clientX-r.left-d/2)+"px;top:"+(e.clientY-r.top-d/2)+"px";el.appendChild(s);setTimeout(()=>s.remove(),650)})}});
app.directive("magnet",{mounted(el){if(matchMedia("(prefers-reduced-motion:reduce)").matches)return;el.addEventListener("pointermove",e=>{if(e.pointerType==="touch")return;const r=el.getBoundingClientRect();el.style.setProperty("--mx",((e.clientX-r.left-r.width/2)*.12).toFixed(1)+"px");el.style.setProperty("--my",((e.clientY-r.top-r.height/2)*.18).toFixed(1)+"px")});el.addEventListener("pointerleave",()=>{el.style.removeProperty("--mx");el.style.removeProperty("--my")})}});
app.directive("focus",{mounted(el){el.focus({preventScroll:true})}});
}
</script>
